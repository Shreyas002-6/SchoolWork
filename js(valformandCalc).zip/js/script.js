function valForm() {
  let x = document.forms["Form"]["exampleInputUsername1"].value;
  let p = document.forms["Form"]["exampleInputPassword1"].value;
  let m = document.forms["Form"]["exampleInputEmail1"].value;
  if (x == "") {
    alert("Username must be filled out");
    return false;
  }
  if (x.length <= 3 && x.length < 10) {
    alert("Username must be in length more than 3 and less than 10");
    return false;
  }
  if (m == "") {
    alert("Enter valid mail");
    return false;
  }
  if (p == "") {
    alert("Password must be entered");
    return false;
  }
  if (p.length < 8) {
    alert("Password must be of or more than 8 letters");
    return false;
  }
  const usernameRegex = /^[a-z0-9_.]+$/
  if (usernameRegex.test(x) == false) {
    alert("Username can only contain numbers, letters and _ .");
    return false;
  }
}
